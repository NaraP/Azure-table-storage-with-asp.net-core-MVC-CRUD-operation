﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MvcAzureTableStorage.IServices;
using MvcAzureTableStorage.Models;

namespace MvcAzureTableStorage.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;
        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        // GET: Customer
        //Get the data from Azure table
        public IActionResult GetAll()
        {
            var entities = _customerService.GetAll();
            var model = entities.Select(x => new CustomerModel
            {
                Group = x.PartitionKey,
                ID = x.RowKey,
                Name = x.Name,
                Addres = x.Address
            });
            return View(model);
        }

        // GET: Customer/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Customer/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CustomerModel customerModel)
        {
            _customerService.CreateOrUpdate(new CustomerEntity
            {
                PartitionKey = customerModel.Group,
                RowKey = Guid.NewGuid().ToString(),
                Name = customerModel.Name,
                Address = customerModel.Addres

            });
            return RedirectToAction("GetAll");
        }

        // GET: Customer/Edit/5
        public ActionResult Edit(string group, string id)
        {
            var item = _customerService.Get(group, id);
            return View("Edit", new CustomerModel
            {
                Group = item.PartitionKey,
                ID = item.RowKey,
                Name = item.Name,
                Addres = item.Address
            });
        }

        // POST: Customer/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CustomerModel customerModel)
        {
            _customerService.CreateOrUpdate(new CustomerEntity
            {
                RowKey = customerModel.ID,
                PartitionKey = customerModel.Group,

                Name = customerModel.Name,
                Address = customerModel.Addres

            });
            return RedirectToAction("GetAll");
        }

        // GET: Customer/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        public IActionResult ConfirmDelete(string group, string id)
        {
            var item = _customerService.Get(group, id);
            return View("Delete", new CustomerModel
            {
                Group = item.PartitionKey,
                ID = item.RowKey,
                Name = item.Name,
                Addres = item.Address
            });

        }

        // POST: Customer/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(string group, string id)
        {
            var item = _customerService.Get(group, id);
            _customerService.Delete(item);
            return RedirectToAction("GetAll");

        }
    }
}