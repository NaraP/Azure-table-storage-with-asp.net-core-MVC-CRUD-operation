﻿using Microsoft.Azure.Cosmos.Table;
using MvcAzureTableStorage.IServices;
using MvcAzureTableStorage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcAzureTableStorage.Services
{
    public class CustomerService : ICustomerService
    {
        private CloudTable mytable = null;

        public CustomerService()
        {
            var storageAccount = CloudStorageAccount.Parse("Your azure storage account here");
            var cloudTableClient = storageAccount.CreateCloudTableClient();
            mytable = cloudTableClient.GetTableReference("Customer");
            mytable.CreateIfNotExists();
        }
        public IEnumerable<CustomerEntity> GetAll()
        {
            var query = new TableQuery<CustomerEntity>();
            var entties = mytable.ExecuteQuery(query);
            return entties;
        }
        public void CreateOrUpdate(CustomerEntity customerEntity)
        {
            var operation = TableOperation.InsertOrReplace(customerEntity);
            mytable.Execute(operation);
        }
        public void Delete(CustomerEntity customerEntity)
        {
            var operation = TableOperation.Delete(customerEntity);
            mytable.Execute(operation);
        }
        public CustomerEntity Get(string partitionKey, string RowId)
        {
            var operation = TableOperation.Retrieve<CustomerEntity>(partitionKey, RowId);
            var result = mytable.Execute(operation);
            return result.Result as CustomerEntity;
        }
    }
}
