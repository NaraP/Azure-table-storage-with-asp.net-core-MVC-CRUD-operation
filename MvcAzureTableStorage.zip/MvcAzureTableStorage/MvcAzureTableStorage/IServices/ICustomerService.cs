﻿using MvcAzureTableStorage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcAzureTableStorage.IServices
{
    public interface ICustomerService
    {
        IEnumerable<CustomerEntity> GetAll();
        void CreateOrUpdate(CustomerEntity customerEntity);
        void Delete(CustomerEntity customerEntity);
        CustomerEntity Get(string partitionKey, string RowId);
    }
}
